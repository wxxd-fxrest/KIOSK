//
//  appleItems.swift
//  AppleStore
//
//  Created by damtea on 4/1/24.
//

import Foundation

struct appleItem {
    let name: String
    var variety: String
    let price: Int
    var color: String
    var count: Int
    var rank: Int
}




